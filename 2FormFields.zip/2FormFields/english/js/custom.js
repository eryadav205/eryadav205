/**
 * Created by Nitish on 16-Jul-21.
 */

 
  	
	
	 
	$(document).ready(function () {

		$('#package-footer').validate({ 
			rules: {
				name: {
					required: true,
					minlength: 5
				},
				phone: {
					required: true,
					minlength: 10,
					number: true 
					},
				user_type:{ required: true}

			}, 
			submitHandler: function (form) { // for demo
				 $('.rush_button').css('opacity','.5');
				$.session.clear();
				var currentURL = $(location).attr('href'); 
				var formData = {
				  currentURL:currentURL,
				  name: $("#name").val(),
				  phone: $("#phone").val(),
				  product_id: $("#product_id").val(),
				};
 

					$.ajax({
						type: "POST",
						url: "https://buynutralyfe.com/api/leadgen/index.php",   
						
						dataType: 'json',
						crossDomain: true,
						data: formData,
						success: function (jsonResult) {
						//var newData = JSON.stringify(jsonResult);
							if(jsonResult.status!= '')
							{
								$("#errMessage").html('<span style="color:red;">'+jsonResult.error+'</span>');

							}	  
							
							if(jsonResult.order_id != '')
							{
								$.session.set("currentURL", currentURL);
								$.session.set("order_id", jsonResult.order_id);
								$.session.set("name", jsonResult.firstname);
								$.session.set("mobile", jsonResult.telephone);
								$.session.set("product_name", jsonResult.products[0].name);
								window.location.href = 'thankyou.html';  
							}
													
							console.log(jsonResult);
						},
						error: function (jqXHR, textStatus) {
							//handle error
						}
					});
				//return false; // for demo
			}
		});
		
		
		$('#package-leftsite').validate({ 
			rules: {
				name: {
					required: true,
					minlength: 5
				},
				phone: {
					required: true,
					minlength: 10,
					number: true 
					},
				user_type:{ required: true}

			}, 
			submitHandler: function (form) { // for demo
				
			
			  $('.rush_button').css('opacity','.5');  
				$.session.clear();
				var currentURL = $(location).attr('href');
				var name = $("#name_left").val();				
				var formData = {
				  currentURL:currentURL,
				  name: name,
				  phone: $("#phone_left").val(),
				  product_id: $("#product_id_left").val(),
				};
 

					$.ajax({
						type: "POST",
						url: "https://buynutralyfe.com/api/leadgen/index.php",   
						
						dataType: 'json',
						crossDomain: true,
						data: formData,
						success: function (jsonResult) {
						//var newData = JSON.stringify(jsonResult);
							if(jsonResult.status!= '')
							{
								$("#errMessage").html('<span style="color:red;">'+jsonResult.error+'</span>');

							}	  
							
							if(jsonResult.order_id != '')
							{
								$.session.set("currentURL", currentURL);
								$.session.set("order_id", jsonResult.order_id);
								$.session.set("name", jsonResult.firstname);
								$.session.set("mobile", jsonResult.telephone);
								$.session.set("product_name", jsonResult.products[0].name);
								window.location.href = 'thankyou.html';  
							}
													
							console.log(jsonResult);
						},
						error: function (jqXHR, textStatus) {
							//handle error
						}
					});

		
			//	return false; // for demo
			}
		});
		

	});

	$('.product-element').click(function(event) {
		product_id = $(this).data('product-id');
		$('.product_id').val(product_id);
		
	});

/*	$('.product-element-footer').click(function(event) {
		
		product_id = $(this).data('product-id');
		
		$('#left_product_id').val(product_id);
		
	});
			 
			*/ 
			 
	/* lead gen */
	
	
	 $(document).ready(function () { 
				$.session.clear();
				var currentURL = $(location).attr('href'); 
				var formData = {
				  currentURL:currentURL,
				  pixel_script:'pixel_script',
				};
					$.ajax({
						type: "POST",
						url: "https://buynutralyfe.com/api/leadgen/index.php",  
					 
						dataType: 'json',
						crossDomain: true,
						data: formData,
						success: function (jsonResult) {
							if(jsonResult.header_scripts !=''){
								$('#header_scripts').append(jsonResult.header_scripts);
							}
							if(jsonResult.body_scripts !=''){
								$('#body_scripts').append(jsonResult.body_scripts);
							}
							 
							if(jsonResult.footer_scripts !=''){
								$('#footer_scripts').append(jsonResult.footer_scripts);
							}							
							//console.log(jsonResult);
						},
						error: function (jqXHR, textStatus) {
							//handle error
						}
					});

		});
		
	
