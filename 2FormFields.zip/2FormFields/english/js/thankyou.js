/**
 * Created by pareen on 02-Jul-15.
 */

 
  $(document).ready(function(){
	
			var payment_method = $('input[name=\'payment_type\']').val(); 
            var product_id = $('input[name=\'product_id\']').val(); 
			var coupon = $('input[name=\'coupon\']').val(); 

            
			 paymenet_details(product_id, payment_method, coupon);
            
	 });  
	 
function paymenet_details(product_id, payment_method, coupon){
   $.post("include/Callthankyou.php", {'product_id' : product_id, 'payment_method' : payment_method, 'coupon' : coupon}, function(data, status){

          $('#result_show_price').html(data);
    });
}


