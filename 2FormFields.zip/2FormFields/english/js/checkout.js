 $(document).ready(function(){
 	$('.ck-box1').addClass('selected');
	$('.ck-box2').removeClass('selected');
	$('.ck-box3').removeClass('selected');
	
	var coupon  =  'D101';
	var product_id = $('#product_id').val();
	var payment_method = $('input[name=\'payment_type\']:checked').val();
	
	Auto_load_Product(product_id, payment_method,coupon);  
 });
 
$(document).ready(function(){
    $('#mobile_verification_div').hide(); 

        var payment_method = $('input[name=\'payment_type\']:checked').val();
   
        $('.ck-box2').click(function(e) {
	 
            $('.ck-box2').addClass('selected');
            $('.ck-box1').removeClass('selected');
            $('.ck-box3').removeClass('selected');
            $('#product_id').val('47');
			var coupon  =  'D101';
            var payment_method = $('input[name=\'payment_type\']:checked').val();
            Auto_load_Product(47, payment_method,coupon);
        });
        $('.ck-box1').click(function(e) {
		 
            $('.ck-box1').addClass('selected');
            $('.ck-box2').removeClass('selected');
            $('.ck-box3').removeClass('selected');
            $('#product_id').val('32');
			var coupon  =  'D101';
            var payment_method = $('input[name=\'payment_type\']:checked').val();
            Auto_load_Product(32, payment_method,coupon); 
        });
        $('.ck-box3').click(function(e) {
		 
            $('.ck-box3').addClass('selected');
            $('.ck-box2').removeClass('selected');
            $('.ck-box1').removeClass('selected');
            $('#product_id').val('53');
			 var coupon  =  'D101';
            var payment_method = $('input[name=\'payment_type\']:checked').val();
            Auto_load_Product(53, payment_method,coupon);
        });




    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    $('#prepaid').click(function() {
        if ($(this).is(':checked')) {
            $('#mobile_verification_div').hide();
            $('#display_amount').addClass('strike');
            $('#display_payu_amount').show();
			 var coupon  =  'D101';
            var payment_method = $('input[name=\'payment_type\']:checked').val();
            var product_id = $('input[name=\'product_id\']').val(); 
            Auto_load_Product(product_id, payment_method,coupon);
        }
    });

    $('#cod').click(function() {
        if ($(this).is(':checked')) {
            $('#mobile_verification_div').show();
            $('#display_amount').removeClass('strike');
            $('#display_payu_amount').hide();           
            var coupon  =  'D101';
            var payment_method = $('input[name=\'payment_type\']:checked').val();
            var product_id = $('input[name=\'product_id\']').val(); 
            Auto_load_Product(product_id, payment_method,coupon);
            var status=GetOTPCode($('input[name=\'email\']').val(),$('input[name=\'telephone\']').val());

           
        }
    });

    $('#prepaid_label').click(function(){
		//alert('ddddd');
        $('#prepaid').prop("checked", true);
        $('#mobile_verification_div').hide();
        $('#display_amount').addClass('strike');
        $('#display_payu_amount').show();
	    var coupon  =  'D101';
        var payment_method = $('input[name=\'payment_type\']:checked').val();
        var product_id = $('input[name=\'product_id\']').val(); 
        Auto_load_Product(product_id, payment_method,coupon);
    });

    $('#cod_label').click(function(){
        $('#cod').prop("checked", true);
        $('#mobile_verification_div').show();
        $('#display_amount').removeClass('strike');
        $('#display_payu_amount').hide();
		
		 var coupon  =  'D101';
        var payment_method = $('input[name=\'payment_type\']:checked').val();
        var product_id = $('input[name=\'product_id\']').val(); 
        Auto_load_Product(product_id, payment_method,coupon);

        var status=GetOTPCode($('input[name=\'email\']').val(),$('input[name=\'telephone\']').val());

    });
  $('#refresh').click(function(){
        $('#cod').prop("checked", true);
        $('#mobile_verification_div').show();
        $('#display_amount').removeClass('strike');
        $('#display_payu_amount').hide();
		 var coupon  =  'D101';
        var payment_method = $('input[name=\'payment_type\']:checked').val();
        var product_id = $('input[name=\'product_id\']').val(); 
        Auto_load_Product(product_id, payment_method,coupon);
//alert($('input[name=\'email\']').val());
       var status=GetOTPCode($('input[name=\'email\']').val(),$('input[name=\'telephone\']').val(),$('input[name=\'order_id\']').val());

    }); 


/*  var code = sessionStorage.getItem('resnew');
  if(code=='' || code==null){    
     var AutoLoaded=GetOTPCode($('input[name=\'email\']').val(),$('input[name=\'telephone\']').val(),$('input[name=\'order_id\']').val());
  } else {
     //$('#code').val(code);
  } */
  

    $('#submit-order').click(function() {  
	
     
       if (document.getElementById("verif_code").value.replace(/\s/g, "") == "") {
            var payment_type = $('input[name=payment_type]:checked').val();
			//alert(payment_type);
				if(payment_type == 'cod'){
					alert("Please enter the OTP code");
					$('#verif_code').focus();
					return false;
				}
        } else {  

            window.onbeforeunload=null;            
            var code = sessionStorage.getItem('resnew');
            var verif_code = $('#verif_code').val();
            var isVisible = $('#verif_code').is(':visible');
            //  alert(isVisible);
            var isHidden = $('#verif_code').is(':hidden');
            //  alert(isHidden);
            if(isHidden==false && isVisible==true){
                    if(verif_code!=code && isHidden==false)
                    {
                        alert('Invalid OTP Code.');
                        return false;       
                    } else if(verif_code == code && isVisible==true){  

                        $('#submit-order').prop('disabled', true);
                        $(this).prop( "disabled", true );            
                        $('#package-payment').submit();
                    }

            } else {     
                $('#submit-order').prop('disabled', true);
             $(this).prop( "disabled", true );
              $('#package-payment').submit();
            }

        }
        //else closed
    });
});




function GetOTPCode(email, phone, order_id){	
 var baseurl = 'https://www.nutralyfe.in/index.php?route=checkout/smscode/sms&email=' +  encodeURIComponent(email)+'&telephone=' +  encodeURIComponent(phone);	
 
        $.ajax({
            url: baseurl,            
            dataType: 'json',
            success: function(json) { 
             var res =json['code'];
             if(json['success']){ 
                 alert(json['success']);
                 
				 
 	var str1 = "shdhsdhs";
    var str2 = order_id;
    var resnew = str1.concat(str2);
	

                 sessionStorage.setItem('resnew', res);
				//alert(sessionStorage.getItem('resnew'));
                  $('.send-sms-to').prop("checked", true);
            
                 return true; 
               } else {
                  alert(json['error']);
               }
            }
        });     
        return false;
 }

 function couponApply(coupon){   
        var payment_method = $('input[name=\'payment_type\']:checked').val();
        var product_id = $('input[name=\'product_id\']').val();
                             
        Auto_load_Product(product_id, payment_method, coupon);
      
}

function Auto_load_Product(product_id, payment_method, coupon){
  //  alert(payment_method+product_id+coupon);    

   $.post("include/CallFeedBackAjax.php", {'product_id' : product_id, 'payment_method' : payment_method, 'coupon' : coupon}, function(data, status){
   // alert(data);
  // $( ".irc_mi" ).remove();
          $('#result_show').html(data);
    });
}


function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
function validatePhone(phone) {
    var re = /^[0-9]+$/;
    return re.test(phone);
}
function validatePincode(pincode) {
    var re = /^\d+$/;
    return re.test(pincode);
}
