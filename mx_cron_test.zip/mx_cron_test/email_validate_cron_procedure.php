<?php 
	include_once('inc/config.php');
	function jValidateEmailUsingSMTP($sToEmail, $sFromDomain = "example.com", $sFromEmail = "sample@example.com", $bIsDebug = false) {

    $bIsValid = true; // assume the address is valid by default..
//    $aEmailParts = explode("@", $sToEmail); // extract the user/domain..
//    getmxrr($aEmailParts[1], ); // get the mx records..
    $aMatches = array("alt4.gmail-smtp-in.l.google.com","gmail-smtp-in.l.google.com","alt1.gmail-smtp-in.l.google.com","alt2.gmail-smtp-in.l.google.com","alt3.gmail-smtp-in.l.google.com");

//    if (sizeof($aMatches) == 0) {
//        return false; // no mx records..
//    }

    foreach ($aMatches as $oValue) {

        if ($bIsValid && !isset($sResponseCode)) {

            // open the connection..
            $oConnection = @fsockopen($oValue, 25, $errno, $errstr, 30);
            $oResponse = @fgets($oConnection);


            // say hello to the server..
            fputs($oConnection, "HELO $sFromDomain\r\n");
            $oResponse = fgets($oConnection);
            $aConnectionLog['HELO'] = $oResponse;

            // send the email from..
            fputs($oConnection, "MAIL FROM: <$sFromEmail>\r\n");
            $oResponse = fgets($oConnection);
            $aConnectionLog['MailFromResponse'] = $oResponse;

            // send the email to..
            fputs($oConnection, "RCPT TO: <$sToEmail>\r\n");
            $oResponse = fgets($oConnection);
            $aConnectionLog['MailToResponse'] = $oResponse;

            // get the response code..
            $sResponseCode = substr($aConnectionLog['MailToResponse'], 0, 3);
            $sBaseResponseCode = substr($sResponseCode, 0, 1);

            // say goodbye..
            fputs($oConnection,"QUIT\r\n");
            $oResponse = fgets($oConnection);

            // get the quit code and response..
            $aConnectionLog['QuitResponse'] = $oResponse;
            $aConnectionLog['QuitCode'] = substr($oResponse, 0, 3);

            if ($sBaseResponseCode == "5") {
                $bIsValid = false; // the address is not valid..
            }

 //  print_r($aConnectionLog); die;

            // close the connection..
            @fclose($oConnection);

        }

    }

    if ($bIsDebug) {
        print_r($aConnectionLog); // output debug info..
    }

    return $bIsValid;

}

	$sql2="CALL fetchEmailRecords(1)";
    $results = mysqli_query($link, $sql2);
	$telephones = array();
	 
		while($data=mysqli_fetch_array($results)){			
	
				$id = $data['id'];
				$email =  $data['email'];
				date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
				$modify_date = date('Y-m-d H:i:s');
    
 
				$bIsEmailValid = jValidateEmailUsingSMTP($email, "gmail.com", "rashid.ashraf134@gmail.com"); //replace $email with mail ID 
					if ($bIsEmailValid) {
						if(strpos(strtolower($email), 'gmail') !== false){ //if valid and is gmail 1
							echo $sql = "UPDATE `tb_email_validate` SET `verified_email` = 1,`varified_date`='".$modify_date."' WHERE `id`= '".$id."'";
							if ($link->query($sql) === TRUE) {
								echo "<br>Record updated successfully";
							} else {
								echo "<br>Error updating record: " . $link->error;
							} 
						}else{ //if valid and is nongmail 2
							echo $sql = "UPDATE `tb_email_validate` SET `verified_email` = 2,`varified_date`='".$modify_date."' WHERE `id`= '".$id."'";
							 if ($link->query($sql) === TRUE) {
								echo "<br>Record updated successfully";
							} else {
								echo "<br>Error updating record: " . $link->error;
							}
						} 
					}else{
						if(strpos(strtolower($email), 'gmail') !== false){ //if invalid and is gmail 0
							echo $sql = "UPDATE `tb_email_validate` SET `verified_email` = 0,`varified_date`='".$modify_date."' WHERE `id`= '".$id."'";
							if ($link->query($sql) === TRUE) {
								echo "<br>Record updated successfully".$email;
							} else {
								echo "<br>Error updating record: " . $link->error;
							} 
						}else{ //if invalid and is nongmail by gmail script. it could be valid.
							echo $sql = "UPDATE `tb_email_validate` SET `verified_email` = 5,`varified_date`='".$modify_date."' WHERE `id`= '".$id."'";
							 if ($link->query($sql) === TRUE) {
								echo "<br>Record updated successfully".$email;
							} else {
								echo "<br>Error updating record: " . $link->error;
							} 
							echo '<br>'.$email.' NULL';
						}
					}
				}
	
	
mysqli_close($link);  

?>
