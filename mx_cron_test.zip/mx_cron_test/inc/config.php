<?php
# Fill our vars and run on cli
# $ php -f db-connect-test.php

$dbname = 'custom';
$dbuser = 'root';
$dbpass = '';
$dbhost = 'localhost';

$link = mysqli_connect($dbhost, $dbuser, $dbpass) or die("Unable to Connect to '$dbhost'");
mysqli_select_db($link, $dbname) or die("Could not open the db '$dbname'");

$link1 = mysqli_connect($dbhost, $dbuser, $dbpass) or die("Unable to Connect to '$dbhost'");
mysqli_select_db($link1, $dbname) or die("Could not open the db '$dbname'");


?>
    